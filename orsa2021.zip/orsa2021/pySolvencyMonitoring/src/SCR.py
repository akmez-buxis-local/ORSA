# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Nov 13, 2018 1:14:17 PM$"

import Settings as Settings
import pandas as pd
import numpy as np

class SCR:
    
    def __init__(self):
        self.eq_corr=pd.read_csv(Settings.workspace+'data/correlation/EQUITY_RISK.csv', sep=',', header=0, index_col=['EQUITY RISK'])
        self.marker_irdw_corr=pd.read_csv(Settings.workspace+'data/correlation/MARKET_RISK_DOWN.csv', sep=',', header=0, index_col=['MARKET RISK'])
        self.market_ir_up_corr=pd.read_csv(Settings.workspace+'data/correlation/MARKET_RISK_UP.csv', sep=',', header=0, index_col=['MARKET RISK'])
        self.count_corr=pd.read_csv(Settings.workspace+'data/correlation/COUNTERPARTY_RISK.csv', sep=',', header=0, index_col=['COUNTERPARTY RISK'])
        self.udw_corr=pd.read_csv(Settings.workspace+'data/correlation/LIFE_UW_RISK.csv', sep=',', header=0, index_col=['LIFE UW RISK'])
        self.bscr_corr=pd.read_csv(Settings.workspace+'data/correlation/BSCR.csv', sep=',', header=0, index_col=['BSCR'])
        
        self.index = ['Equity risk', 'Market risk', 'Counterparty default risk', 'Life underwriting risk', 'Diversification', 'BSCR', 'Operational risk', 'Op premium', 'Op provisions', 'UL expenses', 'Loss-absorbing capacity of technical provisions', 'Loss-absorbing capacity of deferred taxes', 'Solvency capital requirement', 'Net future discretionary benefits']
        self.data = []
        self.s25 = pd.DataFrame({})
        
    def get_s25(self):
        return self.s25
        
    def fill_s25(self, sensi_name, sensi_param, rc_standalone, dtl, op_risk, **kwargs):
        self.data = []
        df_rc = rc_standalone.get_rc(sensi_name)
        bscr_net = self.__bscr_php(sensi_name, df_rc, 'NET').loc[('BSCR', 'NET')][0].item()
        bscr_gross = self.__bscr_php(sensi_name, df_rc, 'GROSS').loc[('BSCR', 'GROSS')][0].item()
        self.data.append(bscr_net-sum(self.data))
        self.data.append(bscr_net)
        life_tp = float(op_risk.op.loc['LIFE TP', sensi_name])
        premium_12 = float(op_risk.op.loc['LIFE PREMIUM 12', sensi_name])
        premium_24 = float(op_risk.op.loc['LIFE PREMIUM 24', sensi_name])
        ul_exp = float(op_risk.op.loc['UL EXPENSES', sensi_name])
        
        op_prov = max(0,0.0045 * life_tp)
        op_prem = 0.04 * premium_12 + max(0,0.04*(premium_12-1.2*premium_24))
        
        op_risk = max(op_prov, op_prem)
        cap = 0.3 * bscr_gross
        
        op_risk = min(op_risk, cap) + 0.25 * ul_exp
        self.data.append(op_risk)
        self.data.append(op_prem)
        self.data.append(op_prov)
        self.data.append(0.25 * ul_exp)
        
        fdb = rc_standalone.php
        tax_rate = float(sensi_param.loc['TAX'][0])
        DTL = dtl
        
        lac_tp = -max(0.0,min(bscr_gross-bscr_net, fdb))
        self.data.append(lac_tp)
        #scr = bscr_gross + lac_tp
        scr = bscr_net 
        scr += op_risk
        lac_dt = - min(tax_rate * scr, DTL)
        scr = scr + lac_dt
        self.data.append(lac_dt)
        
        self.data.append(scr)
        
        self.data.append(fdb)

        df = pd.DataFrame({sensi_name: pd.Series(self.data, index=self.index)})
        
        if self.s25.empty:
            self.s25 = df
        else:
            self.s25 = pd.concat([self.s25, df], axis=1)
        
    def __bscr_php(self, sensi_name, rc_standalone, php):
        eq_risk = self.__div_risk(sensi_name, self.eq_corr, rc_standalone, php)
        rc = pd.concat([rc_standalone, eq_risk])
        
        market_corr = self.marker_irdw_corr
        if rc_standalone.loc[('INTEREST RATE RISK DOWN','NET')].values < rc_standalone.loc[('INTEREST RATE RISK UP','NET')].values:
            market_corr = self.market_ir_up_corr
            
        market_risk = self.__div_risk(sensi_name, market_corr, rc, php)
        count_risk = self.__div_risk(sensi_name, self.count_corr, rc_standalone, php)
        life_udw_risk = self.__div_risk(sensi_name, self.udw_corr, rc_standalone, php)
        
        if php == 'NET':
            self.data.append(eq_risk.loc[('EQUITY RISK', 'NET')][0].item())
            self.data.append(market_risk.loc[('MARKET RISK', 'NET')][0].item())
            self.data.append(count_risk.loc[('COUNTERPARTY RISK', 'NET')][0].item())
            self.data.append(life_udw_risk.loc[('LIFE UW RISK', 'NET')][0].item())
        
        rc_level_2 = pd.concat([market_risk, life_udw_risk, count_risk])
        
        return self.__div_risk(sensi_name, self.bscr_corr, rc_level_2, php)
        
        
    def __div_risk(self, sensi_name, corr_tab, rc_standalone, php):
        rc_net = rc_standalone.xs(php, level=1)
        undv_risk = corr_tab.join(rc_net)
        corr_mat = np.asarray(undv_risk.drop(sensi_name, axis=1))
        vector = undv_risk[sensi_name].tolist()
        res = np.sqrt(np.vdot(vector,np.dot(corr_mat,vector)))
        return pd.DataFrame({'RISK': [corr_tab.index.name], 'PHP': [php], sensi_name: [res]}).set_index(['RISK','PHP'])