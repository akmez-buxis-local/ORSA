# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Oct 11, 2020 12:00:23 PM$"

from plotly import graph_objects as go

class waterfall:
    
    def __init__(self, sr_results, measure, sequence):
        fig = go.Figure()

        fig.add_trace(go.Waterfall(
        name = "Solvency ratio - PD 2020",
        x = [sensi for sensi in measure],
        measure = [measure[sensi] for sensi in measure],
        y = self._impact(sr_results, measure, sequence, "SR"),
        base = 0
        ))

        fig.update_layout(
        title = "Solvency ratio - PD 2020",
        )

        fig.show()
        
    def _impact(self, sr_results, measure, sequence, variable):
        res = []
        for sensi in sequence:
            if measure[sensi] == "absolute":
                res.append(sr_results.loc[sr_results["sensi"]==sensi, variable].item())
            elif measure[sensi] == "relative":
                res.append(sr_results.loc[sr_results["sensi"]==sensi, variable].item()-sr_results.loc[sr_results["sensi"]==sequence[sensi], variable].item())
            elif measure[sensi] == "total":
                res.append(None)
            else:
                raise ValueError(measure[sensi] + 'is not a valid measure')
        return res
