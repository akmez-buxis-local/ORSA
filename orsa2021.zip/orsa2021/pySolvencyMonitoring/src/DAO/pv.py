# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Jun 7, 2020 11:53:27 AM$"

import pandas as pd
import Settings as Settings

class pv:
    
    __AuM_driven = ['res_bop', 'pv_cl_dth', 'pv_cl_mat', 'pv_cl_surr', 'pv_comm', 'pvfp_bf_exp', 'rm']
    
    __item_drivers = {
    'BEL': 'pvfp_bf_exp',
    'RM': 'rm'}
    
    def __init__(self):
        self.pv = pd.read_csv(Settings.workspace+'data/own_funds/PV.csv', sep=',', index_col = ['FUND_NAME'], thousands = ' ')
        self.BEL_shock = 0
        self.RM_shock = 0
        self.driver_lmass = 1
        self.driver_eq = 1
        self.index = ['PVFP AZFR', 'PVFP UL', 'PV_LIAB AZFR', 'PV_LIAB UL', 'RM AZFR', 'RM UL']
        data = []
        self._enrich_data(data)
        
        self.projection = pd.DataFrame({'initial_state': pd.Series(data, index=self.index)})
        
    def shock_AuM(self, lob , sensi, shock):
        data = []
        res = self.pv.loc[lob, 'res_bop']
        shock_impact = (1 + shock) * self.pv.copy().loc[lob, self.__AuM_driven]
        self.BEL_shock = self.pv.loc[lob, 'pvfp_bf_exp'] - shock_impact['pvfp_bf_exp']
        self.RM_shock = shock_impact['rm'] - self.pv.loc[lob, 'rm'] 
        self.driver_lmass = 1 - self.BEL_shock / self.pv.loc[lob, 'pvfp']
        self.driver_eq =  1 + shock   
        self.pv.loc[lob, self.__AuM_driven] = shock_impact
        self.pv.loc[lob, 'pv_liab'] = self.pv.loc[lob, 'pv_cl_dth'] + self.pv.loc[lob, 'pv_cl_mat'] + self.pv.loc[lob, 'pv_cl_surr'] + self.pv.loc[lob, 'pv_comm'] + self.pv.loc[lob, 'pv_exp']
        self.pv.loc[lob, 'pvfp'] = self.pv.loc[lob, 'pvfp'] - self.BEL_shock
        self.pv.loc[lob, 'rm'] = self.pv.loc[lob, 'rm'] + self.RM_shock
        
        self._enrich_data(data)
        df = pd.DataFrame({sensi: pd.Series(data, index=self.index)})
        
        if self.projection.empty:
            self.projection = df
        else:
            self.projection = pd.concat([self.projection, df], axis=1)
        
    def _enrich_data(self, data):
        data.append(self.pv.loc['AZFR', 'pvfp'])
        data.append(self.pv.loc['UL', 'pvfp'])
        data.append(self.pv.loc['AZFR', 'pv_liab'])
        data.append(self.pv.loc['UL', 'pv_liab'])
        data.append(self.pv.loc['AZFR', 'rm'])
        data.append(self.pv.loc['UL', 'rm'])
        return data
