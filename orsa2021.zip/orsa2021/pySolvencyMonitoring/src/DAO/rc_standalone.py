# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Nov 13, 2018 1:27:27 PM$"

import Settings as Settings
import pandas as pd
import math

class rc_standalone:
    
    def get_rc(self, sensi_name):
        return self._rc_standalone[sensi_name].to_frame(name = sensi_name)

class rc_standalone_manual(rc_standalone):
    
    def __init__(self):
        self._rc_standalone = pd.read_csv(Settings.workspace+'data/rc/rc_standalone.csv', sep=',', index_col=['RISK','PHP'])

class rc_standalone_qrt(rc_standalone):
    
    def __init__(self, lu_fund_report, s_26_01, s_26_02):
        self.s_26_01 = s_26_01
        self.s_26_02 = s_26_02
        self.php = lu_fund_report.php
        lu_fd_rp = lu_fund_report.aggregate().reset_index()
        mkt = pd.concat([s_26_01.qrt.reset_index(), s_26_02.qrt.reset_index()])
        mkt_mg = mkt.copy()
        mkt_mg['PHP'] = 'GROSS'
        mkt_ps = mkt.copy()
        mkt_ps['PHP'] = 'NET'
        col = [x for x in lu_fd_rp.columns if x not in ['RISK','PHP']][0]
        res = pd.merge(left = lu_fd_rp,
                        right = pd.concat([mkt_mg, mkt_ps]),
                        how = 'outer',
                        on = ['RISK', 'PHP']).fillna(0)
        res = res.rename(columns = {col: 'liab_'+col, 'Shock asset': 'asset_'+col})
        res[col] = res['liab_'+col] + res['asset_'+col]
        
        self._rc_standalone = res[['RISK', 'PHP', 'liab_'+col, 'asset_'+col, col]].set_index(['RISK', 'PHP'])
        
    def new(self, sensi_name, ref_sensi, lu_fund_report, **kwargs):
        self.php = lu_fund_report.php
        res = lu_fd_rp = lu_fund_report.aggregate()
        self._rc_standalone['liab_'+sensi_name] = lu_fd_rp[sensi_name]
        self._rc_standalone['asset_'+sensi_name] = self._rc_standalone['asset_'+ref_sensi]
        self._rc_standalone = self._rc_standalone.fillna(0).reset_index()
        
        if('RE' in kwargs.keys() and not(math.isnan(kwargs['RE']))):
            self._rc_standalone.loc[self._rc_standalone['RISK'] == 'PROPERTY RISK', 'asset_'+sensi_name] = self._rc_standalone.loc[self._rc_standalone['RISK'] == 'PROPERTY RISK', 'asset_'+sensi_name] * (1 + kwargs['RE'])
        if('COUNT1' in kwargs.keys() and not(math.isnan(kwargs['COUNT1']))):
            self._rc_standalone.loc[self._rc_standalone['RISK'] == 'TYPE 1 EXPOSURES', 'asset_'+sensi_name] = self._rc_standalone.loc[self._rc_standalone['RISK'] == 'TYPE 1 EXPOSURES', 'asset_'+sensi_name] * (1 + kwargs['COUNT1'])
        if('COUNT2' in kwargs.keys() and not(math.isnan(kwargs['COUNT2']))):
            self._rc_standalone.loc[self._rc_standalone['RISK'] == 'TYPE 2 EXPOSURES', 'asset_'+sensi_name] = self._rc_standalone.loc[self._rc_standalone['RISK'] == 'TYPE 2 EXPOSURES', 'asset_'+sensi_name] * (1 + kwargs['COUNT2'])
        if('CS_RISK' in kwargs.keys() and not(math.isnan(kwargs['CS_RISK']))):
            self._rc_standalone.loc[self._rc_standalone['RISK'] == 'SPREAD RISK', 'asset_'+sensi_name] = self._rc_standalone.loc[self._rc_standalone['RISK'] == 'SPREAD RISK', 'asset_'+sensi_name] * (1 + kwargs['CS_RISK'])
        
        self._rc_standalone[sensi_name] = self._rc_standalone['liab_'+sensi_name] + self._rc_standalone['asset_'+sensi_name]
        self._rc_standalone  = self._rc_standalone .set_index(['RISK', 'PHP'])
        
    def get_df(self):
        return self._rc_standalone

