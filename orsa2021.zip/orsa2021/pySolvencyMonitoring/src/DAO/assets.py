# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Jul 24, 2020 3:10:46 PM$"

import pandas as pd
import numpy as np
import Settings as Settings

class assets:
    
    __columns = ["CREDIT_RATING","ISSUER_BE","COUNTRY_OF_RISK","MARKET_VAL_BE"]

    
    def __init__(self):
        """
        Reads assets and spread data under "data/asset" and add a spread category to assets data

        Returns
        -------
        None.

        """
        self.main_file = pd.read_csv(Settings.workspace + "data/asset/main_file_IDS.csv", sep=',', encoding = 'latin_1')
        self.spread_data = pd.read_csv(Settings.workspace + "data/asset/spread_data.csv",sep=',', encoding = 'latin_1')
        
        # Filter on fixed income assets and keep only necessary columns
        self.main_file = self.main_file.loc[(self.main_file["CART_ASSET_CLASS_L1_CODE"]=="FI") 
                                            & (self.main_file["ASSET_TYPE"]=="FI")
                                            & (self.main_file["INPUT_TBL"]!="residual_input"),
                                            self.__columns]
        
        # Build the spread category
        self.main_file["SPREAD_CATEGORY"]=""
        self.main_file.loc[self.main_file["ISSUER_BE"]=="GO","SPREAD_CATEGORY"]=self.main_file.loc[self.main_file["ISSUER_BE"]=="GO","COUNTRY_OF_RISK"].apply(lambda x : "EUR-SPREAD-GOV-"+x)
        self.main_file.loc[self.main_file["ISSUER_BE"]=="CO","SPREAD_CATEGORY"]=self.main_file.loc[self.main_file["ISSUER_BE"]=="CO","CREDIT_RATING"].apply(lambda x : "EUR-SPREAD-CORP-"+x)
        
        
    def cs_shock(self):
        """
        Calculate the average change in spread according to:
            - beginning of period positions
            - spreads beginning of period
            - actual spreads
        Not all assets are expected to be covered by the spread category.
        A print allows to check the percentage of the portfolio covered.

        Returns
        -------
        float            The average change in spread.

        """
        avg_spd = pd.merge(left=self.main_file, 
                           right=self.spread_data,
                           how="left",
                           on="SPREAD_CATEGORY")
        
        # Print the percentage of spread categories coverage
        uncovered_mv = (avg_spd.loc[avg_spd["SPREAD_REFERENCE"].isna()
                                ,"MARKET_VAL_BE"]).sum()
        
        total_mv = avg_spd["MARKET_VAL_BE"].sum()
        print(str(np.round((1-uncovered_mv / total_mv)*100,2))
              + " % of the portfolio is covered by the spread categories")
        
        # Keep only recognized categories
        avg_spd = avg_spd.loc[~(avg_spd["SPREAD_CATEGORY"].isna())]
        
        # Calculate the average change in spread
        avg_spd["MARKET_VAL_BE"] = avg_spd["MARKET_VAL_BE"] / avg_spd["MARKET_VAL_BE"].sum()
        spread_reference = float((avg_spd["MARKET_VAL_BE"] * avg_spd["SPREAD_REFERENCE"]).sum())
        spread_actual = float((avg_spd["MARKET_VAL_BE"] * avg_spd["SPREAD_ACTUAL"]).sum())
        swap_reference= float(self.spread_data.loc[self.spread_data["SPREAD_CATEGORY"]=="Swap Daily","SPREAD_REFERENCE"])
        swap_actual= float(self.spread_data.loc[self.spread_data["SPREAD_CATEGORY"]=="Swap Daily","SPREAD_ACTUAL"])
      
        return (spread_actual - swap_actual*0) - (spread_reference - swap_reference*0)
        
       
    
    
