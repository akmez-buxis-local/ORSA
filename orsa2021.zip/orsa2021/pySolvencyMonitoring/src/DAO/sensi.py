# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Nov 13, 2018 5:41:52 PM$"

import Settings as Settings
import pandas as pd
from DAO.op_risk import op_risk

class sensi:
    
    _type = {
    'MVA': float, 
    'BEL': float,
    'RM': float, 
    'DTL': float,
    'OF': float,
    'DIV': float, 
    'IR': float, 
    'CS': float,
    'VA': float, 
    'INFL': float,
    'RE': float,
    'SA': float,
    'EXP': float,
    'COUNT1': float,
    'COUNT2': float,
    'LIFE_PREMIUM_12': float,
    'LIFE_PREMIUM_24': float,
    'AuM_AZFR': float,
    'AuM_UL': float,
    'OP_REL': float,
    'DIVIDEND': float,
    'RC':str,
    'OF_measure':str,
    'CS_RISK': float}
    
    def __init__(self):
        self.sensi = pd.read_csv(Settings.workspace+'data/run/sensi.csv', sep=',', index_col=['PARAM'])
        self.op_risk = op_risk()
        
    def ref_sensi(self, sensi):
        return self.sensi.loc['REF_SENSI', sensi]
    
    def item(self, sensi, item_name):
        return self._type[item_name](self.sensi.loc[item_name, sensi])
    
    def get_sensi_list(self):
        return self.sensi.columns.values
    
    def get_measure(self):
        return self.sensi.loc['measure',:].to_dict()
    
    def get_sequence(self):
        return self.sensi.loc['REF_SENSI',:].to_dict()
    
    def get_param(self, sensi_name):
        return self.sensi[sensi_name].to_frame(name = sensi_name)
    
    def shock(self, sensi_name):
        type_override = self._type.copy()
        type_override["CS"] = type(self.sensi.loc["CS", sensi_name]) 
        return dict([(k, type_override[k](self.sensi.loc[k, sensi_name])) for k in ['IR', 'CS', 'VA', 'INFL','RE', 'SA', 'EXP', 'COUNT1', 'COUNT2', 'LIFE_PREMIUM_12', 'LIFE_PREMIUM_24', 'AuM_AZFR', 'AuM_UL', 'OP_REL', 'DIVIDEND', 'CS_RISK']])
