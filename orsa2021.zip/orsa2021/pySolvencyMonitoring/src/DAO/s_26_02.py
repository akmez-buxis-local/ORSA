# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$May 29, 2020 4:38:00 PM$"

import Settings as Settings
import pandas as pd

class s_26_02:
    
    __conc_risks ={
    'Type 1 exposures': 'TYPE 1 EXPOSURES', 
    'Type 2 exposures': 'TYPE 2 EXPOSURES'}
    
    def __init__(self):
        qrt = pd.read_csv(Settings.workspace+'data/rc/S.26.02.csv', sep=',', skiprows = 10, thousands = ' ')
        qrt = qrt.rename(columns = {'Counterparty default risk - Basic information': 'RISK', 'C0080': 'Shock asset'})
        qrt = qrt.loc[qrt['RISK'].isin(self.__conc_risks.keys()), ['RISK', 'Shock asset']]
        qrt['RISK'] = qrt['RISK'].apply(lambda x: self.__conc_risks[x])
        
        self.qrt = qrt.set_index(['RISK'])