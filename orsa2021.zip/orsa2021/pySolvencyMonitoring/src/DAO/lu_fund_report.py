# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$May 29, 2020 11:00:55 AM$"

import Settings as Settings
import pandas as pd
import math

class lu_fund_report:
    
    __index = ['Run number','RUNDATE','HIERARCHY_LEVEL','CURRENCY','RUN_TYPE']
    
    __risk_mapping = {
    'MORT_LEVEL_UP': 'MORTALITY RISK',
    'LONG_LEVEL_DOWN': 'LONGEVITY RISK',
    'MAINT_EXP': 'EXPENSES RISK',
    'MORT_LEVEL_CAT': 'CAT',
    'MORB_LEVEL_UP': 'DISABILITY RISK',
    'REVISION': 'REVISION RISK',
    'LAPSE': 'LAPSE RISK',
    'INT_UP': 'INTEREST RATE RISK UP',
    'INT_DOWN': 'INTEREST RATE RISK DOWN',
    'EQ_GLOBAL_DOWN': 'TYPE 1',
    'EQ_OTHER_DOWN': 'TYPE 2',
    'RE_DOWN': 'PROPERTY RISK',
    'FX': 'CURRENCY RISK'}
    
    __AuM_driven = [
    'LAPSE_LEVEL_UP',
    'LAPSE_LEVEL_DOWN',
    'LAPSE_MASS',
    'EQ_GLOBAL_DOWN',
    'EQ_OTHER_DOWN']
    
    __lob_mapping = {
    'LU0003_UL': 'UL',
    'LU0003_AZFR': 'AZFR',
    'LU0003_exNemian': 'NEMIAN',
    'LU0003_LXCLA': 'LXCLA',
    'LU0003_LXCLAWOPB': 'LXCLAWOPB',
    'LU0003_ANN': 'ANN',
    'LU0003_CDFIN': 'CDFIN',
    'LU0003_LXEUR': 'LXEUR'}

    def __init__(self):
        self.php, self.fund_sens_mkt, self.fund_sens_uw = self.__load()
        
    def __load(self,subpath=''):
        mkt = pd.read_csv(Settings.workspace+'data/rc/'+subpath+'/03_FUND_SENS_MKT_NON_ALIM.csv', sep=',')
        uw = pd.read_csv(Settings.workspace+'data/rc/'+subpath+'/02_FUND_SENS_UW_NON_ALIM.csv', sep=',')
        
        
        php = (mkt.loc[mkt['RUN_TYPE'] == 'BE', 'PV_LIABS_MG'] - mkt.loc[mkt['RUN_TYPE'] == 'BE', 'PV_LIABS']).sum()
        
        fund_sens_mkt = self.__initialise(mkt)
        fund_sens_uw = self.__initialise(uw)
        return php, fund_sens_mkt, fund_sens_uw
        
        
    def __initialise(self, df_input):
        self.php = (df_input.loc[df_input['RUN_TYPE'] == 'BE', 'PV_LIABS_MG'] - df_input.loc[df_input['RUN_TYPE'] == 'BE', 'PV_LIABS']).sum()
        run_date = df_input['RUNDATE'].tolist()[0]
        ps = df_input[['HIERARCHY_LEVEL','CURRENCY','RUN_TYPE','PV_LIABS']].rename(columns = {'PV_LIABS': run_date})
        ps['PHP'] = 'NET'
        mg = df_input[['HIERARCHY_LEVEL','CURRENCY','RUN_TYPE','PV_LIABS_MG']].rename(columns = {'PV_LIABS_MG': run_date})
        mg['PHP'] = 'GROSS'
        res = pd.concat([ps, mg])
        res['HIERARCHY_LEVEL'] = res['HIERARCHY_LEVEL'].apply(lambda x: self.__lob_mapping[x])
        res = pd.merge(left = res,\
                        right = res.loc[res['RUN_TYPE'] == 'BE', ['PHP','HIERARCHY_LEVEL', run_date]].rename(columns = {run_date: 'BE'}),
                        how = 'left',
                        on = ['HIERARCHY_LEVEL', 'PHP'])
        res[run_date] = res['BE'] - res[run_date]
        res = res.loc[res['RUN_TYPE'].apply(lambda x: any([y in x for y in self.__risk_mapping.keys()]))].drop(columns = ['BE'])
        
        return res
    
    def new(self, sensi, ref_sensi, pv, rc_path='nan', **kwargs):
        self.fund_sens_mkt[sensi] = self.fund_sens_mkt[ref_sensi]
        self.fund_sens_uw[sensi] = self.fund_sens_uw[ref_sensi]
        if('EXP' in kwargs.keys() and not(math.isnan(kwargs['EXP']))):
            self.fund_sens_uw.loc[self.fund_sens_uw['RUN_TYPE'] == 'MAINT_EXP', sensi] = self.fund_sens_uw.loc[self.fund_sens_uw['RUN_TYPE'] == 'MAINT_EXP', sensi] * (1 + kwargs['EXP'])
        if('SA' in kwargs.keys() and not(math.isnan(kwargs['SA']))):
            self.fund_sens_mkt.loc[self.fund_sens_mkt['RUN_TYPE'] == 'EQ_GLOBAL_DOWN', sensi] = self.fund_sens_mkt.loc[self.fund_sens_mkt['RUN_TYPE'] == 'EQ_GLOBAL_DOWN', sensi] * (0.29 + kwargs['SA']) / 0.29
            self.fund_sens_mkt.loc[self.fund_sens_mkt['RUN_TYPE'] == 'EQ_OTHER_DOWN', sensi] = self.fund_sens_mkt.loc[self.fund_sens_mkt['RUN_TYPE'] == 'EQ_OTHER_DOWN', sensi] * (0.39 + kwargs['SA']) / 0.39
        if('AuM_AZFR' in kwargs.keys() and not(math.isnan(kwargs['AuM_AZFR']))):
            self.fund_sens_uw.loc[self.fund_sens_uw['RUN_TYPE'].isin(self.__AuM_driven) & (self.fund_sens_uw['HIERARCHY_LEVEL'] == 'AZFR'), sensi] = self.fund_sens_uw.loc[self.fund_sens_uw['RUN_TYPE'].isin(self.__AuM_driven) & (self.fund_sens_uw['HIERARCHY_LEVEL'] == 'AZFR'), sensi] * pv.driver_lmass
        if('AuM_UL' in kwargs.keys() and not(math.isnan(kwargs['AuM_UL']))):
            self.fund_sens_uw.loc[self.fund_sens_uw['RUN_TYPE'].isin(self.__AuM_driven) & (self.fund_sens_uw['HIERARCHY_LEVEL'] == 'UL'), sensi] = self.fund_sens_uw.loc[self.fund_sens_uw['RUN_TYPE'].isin(self.__AuM_driven) & (self.fund_sens_uw['HIERARCHY_LEVEL'] == 'UL'), sensi] * pv.driver_lmass
            self.fund_sens_mkt.loc[self.fund_sens_mkt['RUN_TYPE'].isin(self.__AuM_driven) & (self.fund_sens_mkt['HIERARCHY_LEVEL'] == 'UL'), sensi] = self.fund_sens_mkt.loc[self.fund_sens_mkt['RUN_TYPE'].isin(self.__AuM_driven) & (self.fund_sens_mkt['HIERARCHY_LEVEL'] == 'UL'), sensi] * pv.driver_eq
        
        if rc_path!='nan':
            php, fund_sens_mkt, fund_sens_uw = self.__load(subpath=rc_path)
            self.fund_sens_uw[sensi] = fund_sens_uw[sensi]
            self.fund_sens_mkt[sensi] = fund_sens_mkt[sensi]
            self.php = php
        
    def aggregate(self):
        res = pd.concat([self.fund_sens_mkt.reset_index(), self.fund_sens_uw.reset_index()]).drop(columns = ['index'])
        res.loc[res['RUN_TYPE'].apply(lambda x: 'FX' in x), 'RUN_TYPE'] = res.loc[res['RUN_TYPE'].apply(lambda x: 'FX' in x), 'RUN_TYPE'].apply(lambda x: x[:3] + x[7:])
        res = res.drop(columns = ['HIERARCHY_LEVEL', 'CURRENCY']).groupby(['RUN_TYPE', 'PHP']).sum().reset_index()
        # Retain maximum of lapse up, down and mass
        res = self.__maximum(res, 'LAPSE')
        
        # Retain maximum of currencies down and up
        res = self.__maximum(res, 'FX')
        
        # Format editing
        res['RUN_TYPE'] = res['RUN_TYPE'].apply(lambda x: self.__risk_mapping[x])
        res = res.rename(columns = {'RUN_TYPE': 'RISK'}).set_index(['RISK', 'PHP'])
        
        return res
    
    def __maximum(self, df_input, shock):
        df = df_input.copy()
        col = [x for x in df.columns if x not in ['HIERARCHY_LEVEL','CURRENCY','RUN_TYPE','PHP']][0]
        max = df.loc[df['RUN_TYPE'].apply(lambda x: shock in x) & (df['PHP'] == 'NET'), ['RUN_TYPE', col]]
        max = max[max[col] == max[col].max()]['RUN_TYPE'].tolist()[0]
        df = df.loc[df['RUN_TYPE'].apply(lambda x: not(shock in x) or (x == max))]
        df.loc[df['RUN_TYPE'] == max, 'RUN_TYPE'] = shock
        return df
        