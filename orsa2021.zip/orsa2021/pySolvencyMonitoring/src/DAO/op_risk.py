# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Nov 13, 2018 6:29:57 PM$"

import Settings as Settings
import pandas as pd
import math

class op_risk:
    
    def __init__(self):
        self.op = pd.read_csv(Settings.workspace+'data/rc/OP_RISK.csv', sep=',', index_col=['VARIABLE'])
        
    def get_or_param(self, op_risk):
        return self.op[op_risk].to_frame(name = op_risk)
    
    def new(self, sensi_name, ref_sensi, **kwargs):
        if sensi_name != ref_sensi:
            self.op[sensi_name] = self.op[ref_sensi]
            if('AuM_AZFR' in kwargs.keys() and not(math.isnan(kwargs['AuM_AZFR']))):
                self.op.loc['LIFE TP', sensi_name] = self.op.loc['LIFE TP', sensi_name] * (1+kwargs['AuM_AZFR'])
            if('LIFE_PREMIUM_12' in kwargs.keys() and not(math.isnan(kwargs['LIFE_PREMIUM_12']))):
                self.op.loc['LIFE PREMIUM 12', sensi_name] = kwargs['LIFE_PREMIUM_12']
            if('LIFE_PREMIUM_24' in kwargs.keys() and not(math.isnan(kwargs['LIFE_PREMIUM_24']))):
                self.op.loc['LIFE PREMIUM 24', sensi_name] = kwargs['LIFE_PREMIUM_24']
        