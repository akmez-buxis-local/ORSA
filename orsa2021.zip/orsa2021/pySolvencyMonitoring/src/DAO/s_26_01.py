# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$May 29, 2020 4:37:47 PM$"

import Settings as Settings
import pandas as pd

class s_26_01:
    
    __mkt_risks = {
    'interest rate down shock' : 'INTEREST RATE RISK DOWN',
    'interest rate up shock': 'INTEREST RATE RISK UP',
    'type 1 equities': 'TYPE 1',
    'type 2 equities': 'TYPE 2',
    'Property risk': 'PROPERTY RISK',
    'bonds and loans': 'SPREAD RISK',
    'downward shock on credit derivatives': 'SPREAD RISK',
    'upward shock on credit derivatives': 'SPREAD RISK',
    'Securitisation positions': 'SPREAD RISK',
    'Market risk concentrations': 'CONCENTRATION RISK',
    'increase in the value of the foreign currency': 'CURRENCY RISK'}
    
    def __init__(self):
        qrt = pd.read_csv(Settings.workspace+'data/rc/S.26.01.csv', sep=',', skiprows = 15, thousands = ' ')
        qrt['Market risk - Basic information'] = qrt['Market risk - Basic information'].apply(lambda x: x.strip())
        qrt = qrt.fillna(0)
        qrt['MV asset'] = qrt['C0020']
        qrt['Shock asset'] = qrt['C0020'] - qrt['C0040']
        qrt['Shock liab.'] = qrt['C0030'] - qrt['C0050']
        qrt.loc[qrt['Market risk - Basic information'] == 'Market risk concentrations', 'Shock asset'] = qrt.loc[qrt['Market risk - Basic information'] == 'Market risk concentrations', 'C0060']
        qrt = qrt.rename(columns = {'Market risk - Basic information': 'RISK'})
        spread_pos = qrt.loc[qrt['RISK'].isin(['downward shock on credit derivatives', 'upward shock on credit derivatives']) & (qrt['Shock asset'] < 0), 'RISK'].tolist()[0]
        self.__mkt_risks.pop(spread_pos)
        qrt = qrt.loc[qrt['RISK'].isin(self.__mkt_risks.keys())]
        qrt['RISK'] = qrt['RISK'].apply(lambda x: self.__mkt_risks[x])
        qrt.loc[qrt['RISK'] == 'SPREAD RISK', 'Shock asset'] = qrt.loc[qrt['RISK'] == 'SPREAD RISK', 'Shock asset'] - qrt.loc[qrt['RISK'] == 'SPREAD RISK', 'Shock liab.']
        self.qrt = qrt[['RISK','Shock asset']].groupby(['RISK']).sum()