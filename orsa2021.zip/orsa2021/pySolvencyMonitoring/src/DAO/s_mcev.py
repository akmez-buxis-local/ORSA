# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Jun 6, 2020 3:20:57 PM$"

import Settings as Settings
import pandas as pd
import numpy as np

class s_mcev:
    
    __ir = {
    'Risk Free Rate -100bp': -0.01,
    'Risk Free Rate +100bp': 0.01,
    'Risk Free Rate -50bp': -0.005,
    'Risk Free Rate +50bp': 0.005}
    
    __cs = {
    'Credit Risk Spreads -100 bps': -0.01,
    'Credit Risk Spreads +100 bps': 0.01}
    
    __exp = {
    'Maintenance Expenses -10%': -0.1,
    'Maintenance Expenses +10%': 0.1}
    
    __re = {
    '-20% in property value' : -0.2,
    '+20% in property value' : +0.2}
    
    __infl = {
    'Maintenance Expenses Inflation +1%': +0.01}
    
    def __init__(self):
        s_mcev = pd.read_csv(Settings.workspace+'data/own_funds/S_MCEV.csv', sep=',', skiprows = 8, thousands = ' ')
        s_mcev = s_mcev.rename(columns = {'Unnamed: 1': 'RUN_TYPE',
                                            'Market Value of Assets (net of reinsurance assets)': 'MVA',
                                            'BEL(Net of reinsurance, stochastic)': 'BEL',
                                            'Risk Margin': 'RM',
                                            'Embedded Value': 'MCEV'})
        s_mcev['RUN_TYPE'] = s_mcev['RUN_TYPE'].apply(lambda x: x.strip())
        s_mcev = s_mcev[['RUN_TYPE', 'MVA', 'BEL', 'RM', 'MCEV']].fillna(0)
        s_mcev = s_mcev.set_index(['RUN_TYPE'])
        self.s_mcev = s_mcev / s_mcev.loc['Central Assumptions']
        
    def ir_sensi(self, item, level):
        return self._q_reg(item, self.__ir)(level)
    
    def cs_sensi(self, item, level):
        return self._q_reg(item, self.__cs)(level)
    
    def exp_sensi(self, item, level):
        return self._q_reg(item, self.__exp)(level)
    
    def re_sensi(self, item, level):
        return self._q_reg(item, self.__re)(level)
    
    def infl_sensi(self, item, level):
        ref = 'Maintenance Expenses Inflation +1%'
        return (self.s_mcev.loc[ref, [item]] * level / self.__infl[ref])[0]
        
    def _q_reg(self, item, sensi):
        x = list(sensi.values()) + [0]
        y = [self.s_mcev.loc[k, [item]].tolist()[0] for k in sensi.keys()] + [0]
        return np.poly1d(np.polyfit(x, y, 2))