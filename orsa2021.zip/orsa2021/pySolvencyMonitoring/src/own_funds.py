# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Jun 6, 2020 5:28:38 PM$"

import pandas as pd
import math

class own_funds:
    
    __df = pd.DataFrame({'sensi': [], 'MVA' : [], 'BEL': [], 'RM': [], 'DTL': [], 'OF': [], 'dividend': []})
    
    def __init__(self, tax_rate, s_mcev, pv, assets):
        self.tax_rate = tax_rate
        self.s_mcev = s_mcev
        self.pv = pv
        self.assets = assets
        
    def get(self, item, sensi_name):
        return self.__df.loc[self.__df['sensi'] == sensi_name, item].tolist()[0]
        
    def new(self, sensi, mva, bel, rm, dtl, of, div):
        self.__df = pd.concat([self.__df, pd.DataFrame({'sensi': [sensi], 'MVA' : [mva], 'BEL': [bel], 'RM': [rm], 'DTL': [dtl], 'OF': [of], 'dividend': [div]})])
    
    def shock(self, sensi, ref_sensi, **kwargs):
        ref = self.__df.loc[self.__df['sensi'] == ref_sensi]
        mva = ref['MVA'].values[0]
        bel = ref['BEL'].values[0]
        rm = ref['RM'].values[0] 
        dtl, of, div, op_rel, dividend  = 0, 0, 0, 0, 0
        if('IR' in kwargs.keys() and not(math.isnan(kwargs['IR']))):
            mva *= 1 + self.s_mcev.ir_sensi('MVA', kwargs['IR'])
            bel *= 1 + self.s_mcev.ir_sensi('BEL', kwargs['IR'])
            rm *= 1 + self.s_mcev.ir_sensi('RM', kwargs['IR'])
        if('CS' in kwargs.keys()):
            cs_shock = 0
            if kwargs['CS'] == 'param':
                cs_shock = self.assets.cs_shock()
            elif not(math.isnan(float(kwargs['CS']))):
                cs_shock = float(kwargs['CS'])
            mva *= 1 + self.s_mcev.cs_sensi('MVA', cs_shock)
            bel *= 1 + self.s_mcev.cs_sensi('BEL', cs_shock)
        if('VA' in kwargs.keys() and not(math.isnan(kwargs['VA']))):
            bel *= 1 + self.s_mcev.ir_sensi('BEL', kwargs['VA'])
        if('INFL' in kwargs.keys() and not(math.isnan(kwargs['INFL']))):
            bel *= 1 + self.s_mcev.infl_sensi('BEL', kwargs['INFL'])
            rm *= 1 + self.s_mcev.infl_sensi('RM', kwargs['INFL'])
        if('RE' in kwargs.keys() and not(math.isnan(kwargs['RE']))):
            mva *= 1 + self.s_mcev.re_sensi('MVA', kwargs['RE'])
            bel *= 1 + self.s_mcev.re_sensi('BEL', kwargs['RE'])
        if('EXP' in kwargs.keys() and not(math.isnan(kwargs['EXP']))):
            bel = ref['BEL'].values[0] * (1 + self.s_mcev.exp_sensi('BEL', kwargs['EXP']))
        if('AuM_AZFR' in kwargs.keys() and not(math.isnan(kwargs['AuM_AZFR']))):
            self.pv.shock_AuM('AZFR', sensi, kwargs['AuM_AZFR'])
            bel += self.pv.BEL_shock
            rm += self.pv.RM_shock
        if('AuM_UL' in kwargs.keys() and not(math.isnan(kwargs['AuM_UL']))):
            self.pv.shock_AuM('UL', sensi, kwargs['AuM_UL'])
            bel += self.pv.BEL_shock
            rm += self.pv.RM_shock
        if('OP_REL' in kwargs.keys() and not(math.isnan(kwargs['OP_REL']))):
            op_rel = kwargs['OP_REL'] - self.tax_rate * kwargs['OP_REL']
        if('DIVIDEND' in kwargs.keys() and not(math.isnan(kwargs['DIVIDEND']))):
            dividend = kwargs['DIVIDEND']
            
        dtl = ref['DTL'].values[0] + (mva - ref['MVA'].values[0] - (bel - ref['BEL'].values[0]) - (rm - ref['RM'].values[0])) * self.tax_rate
        of = ref['OF'].values[0] + op_rel + dividend + (mva - ref['MVA'].values[0] - (bel - ref['BEL'].values[0]) - (rm - ref['RM'].values[0])) - (dtl - ref['DTL'].values[0])
        
        div = ref['dividend'].values[0]
        self.new(sensi, mva, bel, rm, dtl, of, div)
        
    def df(self):
        return self.__df