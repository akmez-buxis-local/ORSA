# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "LBULABOI"
__date__ = "$Nov 13, 2018 1:13:55 PM$"

from SCR import SCR
from DAO.rc_standalone import rc_standalone_qrt
from DAO.sensi import sensi
from DAO.lu_fund_report import lu_fund_report
from DAO.s_mcev import s_mcev
from DAO.pv import pv
from DAO.assets import assets
from DAO.op_risk import op_risk
from DAO.s_26_01 import s_26_01
from DAO.s_26_02 import s_26_02
#from waterfall import waterfall
import Settings as Settings
from own_funds import own_funds
import pandas as pd

if __name__ == "__main__":
    lu_fund_report = lu_fund_report()
    rc_standalone = rc_standalone_qrt(lu_fund_report, s_26_01(), s_26_02())
    sensi = sensi()
    sensi.get_measure()
    scr = SCR()
    s_mcev = s_mcev()
    pv = pv()
    assets = assets()
    print("Change in spread: " + str(assets.cs_shock()))
    op_risk = op_risk()
    own_funds = own_funds(0.2494, s_mcev, pv, assets)
    
    for sensi_name in sensi.get_sensi_list():
        #scr.fill_s25(sensi_name, sensi.get_param(sensi_name), rc_standalone)
        ref_sensi = sensi.ref_sensi(sensi_name)
        if sensi_name == ref_sensi:
            own_funds.new(sensi_name, sensi.item(sensi_name, 'MVA'), sensi.item(sensi_name, 'BEL'), sensi.item(sensi_name, 'RM'), sensi.item(sensi_name, 'DTL'), sensi.item(sensi_name, 'OF'), sensi.item(sensi_name, 'DIV'))
            op_risk.new(sensi_name, ref_sensi, **sensi.shock(sensi_name))
        else:
            if sensi.item(sensi_name,'OF_measure')=='absolute':
                own_funds.new(sensi_name, sensi.item(sensi_name, 'MVA'), sensi.item(sensi_name, 'BEL'), sensi.item(sensi_name, 'RM'), sensi.item(sensi_name, 'DTL'), sensi.item(sensi_name, 'OF'), sensi.item(sensi_name, 'DIV'))
            else:
                own_funds.shock(sensi_name, ref_sensi, **sensi.shock(sensi_name))
            
            rc_path = sensi.item(sensi_name,'RC')
                
            lu_fund_report.new(sensi_name, ref_sensi, pv, rc_path=rc_path, **sensi.shock(sensi_name))
            rc_standalone.new(sensi_name, ref_sensi, lu_fund_report, **sensi.shock(sensi_name))
            op_risk.new(sensi_name, ref_sensi, **sensi.shock(sensi_name))
        # op provisions not correct, need TP gross sensitivities
        scr.fill_s25(sensi_name, sensi.get_param(sensi_name), rc_standalone, own_funds.get('DTL', sensi_name), op_risk, **sensi.shock(sensi_name))
    
    pv.projection.to_csv(Settings.workspace + 'data/output/tp.csv')
    
    lu_fund_report.fund_sens_mkt.to_csv(Settings.workspace + 'data/output/mkt.csv')
    lu_fund_report.fund_sens_uw.to_csv(Settings.workspace + 'data/output/uw.csv')
    rc_standalone.get_df().to_csv(Settings.workspace + 'data/output/rc_standalone.csv')
    s_25 = scr.get_s25()
    scr = s_25.loc['Solvency capital requirement'].reset_index().rename(columns = {'index': 'sensi', 'Solvency capital requirement': 'SCR'})
    of = own_funds.df()
    res = pd.merge(left = of,
                    right = scr, 
                    on = 'sensi')
    res["SR"] = res["OF"] / res["SCR"]
    res.to_csv(Settings.workspace + 'data/output/SR_results.csv')
    
    #waterfall(res, sensi.get_measure(), sensi.get_sequence())
    
    s_25.to_csv(Settings.workspace+'data/output/s25.csv')
    
