# -*- coding: utf-8 -*-
"""
Created on Wed Feb  3 09:26:55 2021

@author: LBULABOI
"""

import pyodbc
import pandas as pd

conn_dwhv5 = pyodbc.connect('DSN=DWH;Trusted_Connection=yes;')
conn_dwhv6 = pyodbc.connect('DSN=DWH_V6;Trusted_Connection=yes;')

sql_v5 = 'Y:/ModelesDev/ActuarialDao/sql/non_core_TP/Solife_v5_product.sql'
sql_v6 = 'Y:/ModelesDev/ActuarialDao/sql/non_core_TP/Solife_v6_product.sql'

sql_trans_v5 = 'Y:/ModelesDev/ActuarialDao/sql/non_core_TP/Solife_v5_trans.sql'
sql_trans_v6 = 'Y:/ModelesDev/ActuarialDao/sql/non_core_TP/Solife_v6_trans.sql'


with open(sql_v5) as f:
        query_v5 = f.read()
        
with open(sql_v6) as f:
        query_v6 = f.read()

with open(sql_trans_v5) as f:
        query_trans_v5 = f.read()
        
with open(sql_trans_v6) as f:
        query_trans_v6 = f.read()
        
position_v5 = pd.read_sql(query_v5,conn_dwhv5)
position_v6 = pd.read_sql(query_v6,conn_dwhv6)

trans_v5 = pd.read_sql(query_trans_v5,conn_dwhv5)
trans_v6 = pd.read_sql(query_trans_v6,conn_dwhv6)

def rename_v5(data):
    rename_col = dict(zip(data.columns, 
                          [col.replace(' ', '_') for col in data.columns]))
    data = data.rename(columns=rename_col)
    data["FUND_VALUE_EUR"] = data["FUND_VALUE_EUR"].apply(lambda x: x.replace(",",".")).astype('float')
    return data

def transform(data, transactions=None):
    if transactions is not None:
        data = data.loc[data["TRANSACTION_TYPE"].isin(transactions),:].copy()
        
    data.loc[~data["TYPE_OF_SECURITY_SHORT"].isin(["GRF_FR","GRF_LU"]), "TYPE_OF_SECURITY_SHORT"] = "UL"
    
    data = data.replace({"UK": "GB"})
    grouping = list(data.columns)
    grouping.remove("FUND_VALUE_EUR")
    data = data.groupby(grouping).sum().reset_index()
    
    lob_name = {'UL': '(UL)', 
                'GRF_FR': '(Euro reinsured)',
                'GRF_LU': '(Euro)'}
    data["QRT_PRODUCT"] = "Global Invest"
    data.loc[data["POLICY_PRODUCT_CODE"].isin(["240-0001","250-0001"]),"QRT_PRODUCT"] = "FD Dresdner"
    data.loc[data["POLICY_PRODUCT_CODE"].isin(["260-0001"]),"QRT_PRODUCT"] = "Dresdner"
    data.loc[data["POLICY_PRODUCT_CODE"].isin(["300-0001"]),"QRT_PRODUCT"] = "PP"
    data.loc[data["POLICY_PRODUCT_CODE"].isin(["200-0001","037-0001","057-0001","067-0001"]),"QRT_PRODUCT"] = "FIPA"
    
    main_country = data["FIRST_APPLICANT_COUNTRY"].isin(["BE","DE","ES","FR","IT","PT","CH","GB"])
    data.loc[main_country,"QRT_PRODUCT"] = data.loc[main_country,"QRT_PRODUCT"] + " " + data.loc[main_country,"TYPE_OF_SECURITY_SHORT"].apply(lambda x: lob_name[x]) + " " + data.loc[main_country,"FIRST_APPLICANT_COUNTRY"]
    data.loc[~main_country,"QRT_PRODUCT"] = data.loc[~main_country,"QRT_PRODUCT"] + " " + data.loc[~main_country,"TYPE_OF_SECURITY_SHORT"].apply(lambda x: lob_name[x]) + " " + "other"

    count = data[["POLICY_NUMBER"]].copy()
    count["NB_LOB"] = 1
    count = count.groupby(["POLICY_NUMBER"]).sum().reset_index()

    data = pd.merge(left = data,
                    right = count,
                    left_on = "POLICY_NUMBER",
                    right_on = "POLICY_NUMBER",
                    how = "left")

    data["NUMBER_OF_POLICIES"] = 1 / data["NB_LOB"]
    
    return data

positions = pd.concat([rename_v5(position_v5), position_v6])

product_pos = transform(positions)
product_pos = product_pos[["QRT_PRODUCT", "FIRST_APPLICANT_COUNTRY", "NUMBER_OF_POLICIES", "FUND_VALUE_EUR"]].groupby(["QRT_PRODUCT"])\
                .agg({"NUMBER_OF_POLICIES": 'sum',
                      "FUND_VALUE_EUR": 'sum',
                      "FIRST_APPLICANT_COUNTRY": lambda x: set(list(x))})
product_pos = product_pos.rename(columns={"NUMBER_OF_POLICIES":"NUMBER_OF_CONTRACTS_EOY"})
product_pos["FIRST_APPLICANT_COUNTRY"]=product_pos["FIRST_APPLICANT_COUNTRY"].apply(lambda x: str(x).replace("'","").replace("{","").replace("}","").replace(",",";").replace(" ",""))

trans = pd.concat([rename_v5(trans_v5), trans_v6])
new_business = transform(trans, transactions=["NEW_BUSINESS", "ADDITION"])

new_business = new_business[["QRT_PRODUCT", "NUMBER_OF_POLICIES", "FUND_VALUE_EUR"]].groupby(["QRT_PRODUCT"])\
                .agg({"NUMBER_OF_POLICIES": 'sum',
                      "FUND_VALUE_EUR": 'sum'})

new_business = new_business.rename(columns = {"NUMBER_OF_POLICIES": "NUMBER_OF_NEW_CONTRACTS_EOY",
                                              "FUND_VALUE_EUR": "TOTAL_AMOUNT_OF_PREMIUM_EOY"})

claims = transform(trans, transactions=["SURRENDER", "WITHDRAWAL", "DEATH"])

claims = claims[["QRT_PRODUCT", "FUND_VALUE_EUR"]].groupby(["QRT_PRODUCT"]).sum()
claims = claims.rename(columns = {"FUND_VALUE_EUR": "TOTAL_AMOUNT_OF_CLAIM_EOY"})
claims["TOTAL_AMOUNT_OF_CLAIM_EOY"] = -claims["TOTAL_AMOUNT_OF_CLAIM_EOY"]

s14_solife = pd.merge(left=product_pos,
                      right=new_business,
                      left_index = True, 
                      right_index = True,
                      how = 'left')

s14_solife = pd.merge(left=s14_solife,
                      right=claims,
                      left_index = True, 
                      right_index = True,
                      how = 'left')

s14_solife[["NUMBER_OF_CONTRACTS_EOY",
            "NUMBER_OF_NEW_CONTRACTS_EOY",
            "TOTAL_AMOUNT_OF_PREMIUM_EOY",
            "TOTAL_AMOUNT_OF_CLAIM_EOY",
            "FIRST_APPLICANT_COUNTRY"]].to_csv("Y:/ModelesDev/ActuarialDao/tests/QRT/S14_solife.csv")


"""
gls_positions = pd.read_csv("Y:/ModelesDev/ActuarialDao/data/GLS_positions.csv")
nb_cnt_eoy_gls = gls_positions.loc[gls_positions["Date_historique"]=='01/01/2021', ["NOCNT", "NOPRO"]].copy().drop_duplicates()
nb_cnt_eoy_gls["NB_CNT"] = 1
nb_cnt_eoy_gls = nb_cnt_eoy_gls[["NOPRO","NB_CNT"]].groupby(["NOPRO"]).sum()
nb_cnt_eoy_gls = nb_cnt_eoy_gls.rename(columns={"NB_CNT": "NUMBER_OF_CONTRACTS_EOY"})
nb_cnt_eoy_gls["NUMBER_OF_NEW_CONTRACTS_EOY"]=0

gls_transactions = pd.read_csv("Y:/ModelesDev/ActuarialDao/data/GLS_transactions.csv")
gls_transactions["CDEVT"] = gls_transactions["CDEVT"].apply(lambda x: x.strip())
contracts = gls_positions[["NOPRO","NOCNT","EFFECTIVE_DATE","SEXE_ASS2"]].drop_duplicates()
gls_transactions = pd.merge(left=gls_transactions,
                            right=contracts,
                            left_on="NOCNT",
                            right_on="NOCNT",
                            how='left')
gls_transactions.loc[gls_transactions["CDEVT"].apply(lambda x: x[0])=="A","AMOUNT"] = -gls_transactions.loc[gls_transactions["CDEVT"].apply(lambda x: x[0])=="A","AMOUNT"]
gls_transactions.loc[gls_transactions["CDEVT"].isin(["QUIT","SCP"]),"CDEVT"]="TOTAL_AMOUNT_OF_PREMIUM_EOY"
gls_transactions.loc[~(gls_transactions["CDEVT"]=="TOTAL_AMOUNT_OF_PREMIUM_EOY"),"CDEVT"]="TOTAL_AMOUNT_OF_CLAIM_EOY"
gls_transactions = gls_transactions[["NOPRO","CDEVT","AMOUNT"]].groupby(["NOPRO","CDEVT"]).sum().reset_index()
gls_transactions["NOPRO"]=gls_transactions["NOPRO"].apply(lambda x: int(x))
gls_transactions = gls_transactions.pivot(index="NOPRO",columns="CDEVT",values="AMOUNT")

s14_gls = pd.merge(left=nb_cnt_eoy_gls,
                   right=gls_transactions,
                   left_index=True,
                   right_index=True,
                   how='left')

s14_gls.to_csv("Y:/ModelesDev/ActuarialDao/tests/QRT/S14_gls.csv")
"""